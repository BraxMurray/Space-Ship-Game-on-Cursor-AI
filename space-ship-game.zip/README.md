# Space Ship Management Game

A web-based micro-management game where you manage a space-traveling ship that occasionally gets attacked by aliens. Defend your ship, manage resources, and explore the galaxy!

## Features

- Resource management (fuel, oxygen, food, crew morale)
- Ship maintenance and upgrades
- Crew assignment and management
- Weapon systems to defend against alien attacks
- Galaxy exploration and missions
- Real-time credit updates across different pages
- Background soundtrack for immersive gameplay

## Setup Instructions

1. Clone this repository
2. Create a virtual environment:
   ```
   python -m venv venv
   ```
3. Activate the virtual environment:
   - Windows: `venv\Scripts\activate`
   - Mac/Linux: `source venv/bin/activate`
4. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
5. Initialize the database:
   ```
   python create_db.py
   ```
6. Run the application:
   ```
   python app.py
   ```
7. Open your browser and navigate to `http://localhost:5000`

## Game Instructions

- Manage your ship's resources carefully
- Assign crew members to different tasks
- Upgrade your weapons to defend against alien attacks
- Explore new galaxies to discover resources and technologies
- Complete missions to progress through the game

## Technologies Used

- Flask (Python web framework)
- SQLAlchemy (Database ORM)
- HTML/CSS/JavaScript (Frontend)
- Bootstrap (UI Framework)
- AJAX for real-time updates

## Project Structure

- `app.py`: Main application file
- `create_db.py`: Database initialization script
- `templates/`: HTML templates
- `static/`: Static assets (CSS, JavaScript, audio)
- `instance/`: Database files (not included in repository)

## Recent Updates

- Added real-time credit updates across different pages
- Implemented background soundtrack for immersive gameplay
- Fixed credit display inconsistencies
- Improved weapon upgrade system 