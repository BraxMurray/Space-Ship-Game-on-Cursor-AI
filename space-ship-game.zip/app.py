from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import random
from datetime import datetime, timedelta, timezone

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev_key_for_testing')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///spacegame.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database
db = SQLAlchemy(app)

# Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    ships = db.relationship('Ship', backref='owner', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Ship(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    fuel = db.Column(db.Integer, default=100)
    oxygen = db.Column(db.Integer, default=100)
    food = db.Column(db.Integer, default=100)
    morale = db.Column(db.Integer, default=100)
    health = db.Column(db.Integer, default=100)
    credits = db.Column(db.Integer, default=1000)
    current_galaxy = db.Column(db.String(80), default="Alpha Centauri")
    crew = db.relationship('CrewMember', backref='ship', lazy=True)
    weapons = db.relationship('Weapon', backref='ship', lazy=True)
    last_attack_time = db.Column(db.DateTime, default=datetime.utcnow)
    
    def update_resources(self, time_passed):
        # Simulate resource consumption based on time passed
        self.fuel = max(0, self.fuel - int(time_passed.total_seconds() / 3600))
        self.oxygen = max(0, self.oxygen - int(time_passed.total_seconds() / 3600))
        self.food = max(0, self.food - int(time_passed.total_seconds() / 7200))
        
        # Check if resources are critically low
        if self.fuel <= 10 or self.oxygen <= 10 or self.food <= 10:
            self.morale = max(0, self.morale - 5)
        
        # Check if ship is in danger
        if self.fuel <= 0 or self.oxygen <= 0:
            self.health = max(0, self.health - 10)
            
        db.session.commit()
    
    def check_for_attack(self):
        now = datetime.utcnow()
        time_since_last_attack = now - self.last_attack_time
        
        # Random chance of attack based on time passed
        attack_chance = min(80, time_since_last_attack.total_seconds() / 3600)
        
        if random.random() * 100 < attack_chance:
            self.last_attack_time = now
            db.session.commit()
            return True
        return False

class CrewMember(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    role = db.Column(db.String(80), nullable=False)  # pilot, engineer, gunner, etc.
    skill_level = db.Column(db.Integer, default=1)
    ship_id = db.Column(db.Integer, db.ForeignKey('ship.id'), nullable=False)
    current_task = db.Column(db.String(80), default="Idle")

class Weapon(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    damage = db.Column(db.Integer, default=10)
    accuracy = db.Column(db.Integer, default=70)  # percentage
    cooldown = db.Column(db.Integer, default=3)  # seconds
    level = db.Column(db.Integer, default=1)
    ship_id = db.Column(db.Integer, db.ForeignKey('ship.id'), nullable=False)

class Alien(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    health = db.Column(db.Integer, default=100)
    damage = db.Column(db.Integer, default=10)
    defense = db.Column(db.Integer, default=5)
    
class Galaxy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False, unique=True)
    danger_level = db.Column(db.Integer, default=1)  # 1-10
    resource_abundance = db.Column(db.Integer, default=5)  # 1-10
    description = db.Column(db.Text)
    resource_points = db.relationship('ResourcePoint', backref='galaxy', lazy=True)

class ResourcePoint(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    credits_available = db.Column(db.Integer, default=100)
    max_credits = db.Column(db.Integer, default=100)
    last_harvested = db.Column(db.DateTime, default=datetime.utcnow)
    regeneration_rate = db.Column(db.Integer, default=10)  # credits per hour
    galaxy_id = db.Column(db.Integer, db.ForeignKey('galaxy.id'), nullable=False)
    
    def regenerate(self):
        now = datetime.now(timezone.utc)
        time_since_harvest = now - self.last_harvested.replace(tzinfo=timezone.utc)
        hours_passed = time_since_harvest.total_seconds() / 3600
        
        # Calculate regenerated credits
        regenerated_credits = int(hours_passed * self.regeneration_rate)
        self.credits_available = int(min(self.max_credits, self.credits_available + regenerated_credits))
        
        return self.credits_available

# Initialize database function
def initialize_db():
    with app.app_context():
        db.create_all()
        
        # Add initial galaxies if none exist
        if Galaxy.query.count() == 0:
            galaxy_names = ["Alpha Centauri", "Sirius System", "Betelgeuse Nebula", "Orion's Belt", "Andromeda Sector"]
            for name in galaxy_names:
                galaxy = Galaxy(
                    name=name,
                    danger_level=random.randint(1, 10),
                    resource_abundance=random.randint(1, 10),
                    description="A newly discovered galaxy."
                )
                db.session.add(galaxy)
            db.session.commit()
            
            # Create resource points for each galaxy
            galaxies = Galaxy.query.all()
            for galaxy in galaxies:
                create_resource_points_for_galaxy(galaxy)

# Helper function to create resource points for a galaxy
def create_resource_points_for_galaxy(galaxy):
    # Generate number of resource points based on resource abundance (more abundance = more points)
    num_points = max(5, min(15, random.randint(3, 8) + galaxy.resource_abundance))
    planet_prefixes = ["Alpha", "Beta", "Gamma", "Delta", "Epsilon", "Zeta", "Eta", "Theta", "Iota", "Kappa"]
    planet_suffixes = ["Prime", "Minor", "Major", "Secundus", "Tertius", "IV", "V", "VI", "VII", "VIII"]
    
    for i in range(num_points):
        # Generate a unique planet name
        prefix = random.choice(planet_prefixes)
        suffix = random.choice(planet_suffixes)
        planet_name = f"{prefix} {suffix}"
        
        # Calculate max credits based on galaxy resource abundance - ensure it's an integer
        max_credits = int(random.randint(50, 150) * (galaxy.resource_abundance / 5))
        
        # Create the resource point
        resource_point = ResourcePoint(
            name=planet_name,
            credits_available=max_credits,
            max_credits=max_credits,
            regeneration_rate=random.randint(5, 20),
            galaxy_id=galaxy.id
        )
        db.session.add(resource_point)
    db.session.commit()

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Check if username already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists!')
            return redirect(url_for('register'))
        
        # Create new user
        new_user = User(username=username)
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.commit()
        
        # Create initial ship for the user
        new_ship = Ship(name="USS Enterprise", user_id=new_user.id)
        db.session.add(new_ship)
        
        # Add initial crew members
        crew_roles = ["Captain", "Engineer", "Pilot", "Gunner", "Science Officer"]
        for role in crew_roles:
            crew_member = CrewMember(name=f"{role} Smith", role=role, ship_id=new_ship.id)
            db.session.add(crew_member)
        
        # Add improved initial weapons
        basic_laser = Weapon(
            name="Basic Laser Cannon", 
            damage=15,  # Increased from 10
            accuracy=75,  # Increased from 70
            ship_id=new_ship.id
        )
        db.session.add(basic_laser)
        
        defensive_shield = Weapon(
            name="Defensive Shield", 
            damage=8,
            accuracy=90,
            ship_id=new_ship.id
        )
        db.session.add(defensive_shield)
        
        db.session.commit()
        
        flash('Registration successful! Please log in.')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            session['user_id'] = user.id
            flash('Login successful!')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('You have been logged out.')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please log in first.')
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    ships = user.ships
    
    if not ships:
        flash('You have no ships. Creating a new one...')
        new_ship = Ship(name="USS Enterprise", user_id=user.id)
        db.session.add(new_ship)
        db.session.commit()
        
        # Add initial crew members
        crew_roles = ["Captain", "Engineer", "Pilot", "Gunner", "Science Officer"]
        for role in crew_roles:
            crew_member = CrewMember(name=f"{role} Smith", role=role, ship_id=new_ship.id)
            db.session.add(crew_member)
        
        # Add improved initial weapons
        basic_laser = Weapon(
            name="Basic Laser Cannon", 
            damage=15,  # Increased from 10
            accuracy=75,  # Increased from 70
            ship_id=new_ship.id
        )
        db.session.add(basic_laser)
        
        defensive_shield = Weapon(
            name="Defensive Shield", 
            damage=8,
            accuracy=90,
            ship_id=new_ship.id
        )
        db.session.add(defensive_shield)
        
        db.session.commit()
        return redirect(url_for('dashboard'))
    
    # For simplicity, we'll just use the first ship
    ship = ships[0]
    
    # Update ship resources based on time passed
    last_update = session.get('last_update')
    if last_update:
        time_passed = datetime.utcnow() - datetime.fromisoformat(last_update)
        ship.update_resources(time_passed)
    
    session['last_update'] = datetime.utcnow().isoformat()
    
    # Check for random alien attack
    attack = ship.check_for_attack()
    
    return render_template('dashboard.html', user=user, ship=ship, attack=attack)

@app.route('/ship/<int:ship_id>')
def ship_details(ship_id):
    if 'user_id' not in session:
        flash('Please log in first.')
        return redirect(url_for('login'))
    
    ship = Ship.query.get_or_404(ship_id)
    
    # Make sure the ship belongs to the logged-in user
    if ship.user_id != session['user_id']:
        flash('Access denied.')
        return redirect(url_for('dashboard'))
    
    return render_template('ship_details.html', ship=ship)

@app.route('/crew/<int:ship_id>')
def manage_crew(ship_id):
    if 'user_id' not in session:
        flash('Please log in first.')
        return redirect(url_for('login'))
    
    ship = Ship.query.get_or_404(ship_id)
    
    # Make sure the ship belongs to the logged-in user
    if ship.user_id != session['user_id']:
        flash('Access denied.')
        return redirect(url_for('dashboard'))
    
    return render_template('crew.html', ship=ship)

@app.route('/assign_task', methods=['POST'])
def assign_task():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please log in first.'})
    
    crew_id = request.form.get('crew_id')
    task = request.form.get('task')
    
    crew_member = CrewMember.query.get_or_404(crew_id)
    ship = Ship.query.get(crew_member.ship_id)
    
    # Make sure the ship belongs to the logged-in user
    if ship.user_id != session['user_id']:
        return jsonify({'success': False, 'message': 'Access denied.'})
    
    crew_member.current_task = task
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Task assigned successfully.'})

@app.route('/hire_crew', methods=['POST'])
def hire_crew():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please log in first.'})
    
    ship_id = request.form.get('ship_id')
    crew_name = request.form.get('crew_name')
    crew_role = request.form.get('crew_role')
    
    ship = Ship.query.get_or_404(ship_id)
    
    # Make sure the ship belongs to the logged-in user
    if ship.user_id != session['user_id']:
        return jsonify({'success': False, 'message': 'Access denied.'})
    
    # Check if the user has enough credits (500 per crew member)
    if ship.credits < 500:
        return jsonify({'success': False, 'message': 'Not enough credits. Hiring a crew member costs 500 credits.'})
    
    # Create new crew member
    new_crew = CrewMember(
        name=crew_name,
        role=crew_role,
        skill_level=random.randint(1, 5),  # Random initial skill level
        ship_id=ship_id,
        current_task="Idle"
    )
    
    # Deduct credits
    ship.credits -= 500
    
    # Add to database
    db.session.add(new_crew)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Crew member hired successfully!', 'ship_credits': ship.credits})

@app.route('/weapons/<int:ship_id>')
def manage_weapons(ship_id):
    if 'user_id' not in session:
        flash('Please log in first.')
        return redirect(url_for('login'))
    
    ship = Ship.query.get_or_404(ship_id)
    
    # Make sure the ship belongs to the logged-in user
    if ship.user_id != session['user_id']:
        flash('Access denied.')
        return redirect(url_for('dashboard'))
    
    # Calculate crew bonus for weapons (0.5 per crew member)
    crew_count = len(ship.crew)
    crew_bonus = crew_count * 0.5
    
    return render_template('weapons.html', ship=ship, crew_bonus=crew_bonus, crew_count=crew_count)

@app.route('/upgrade_weapon', methods=['POST'])
def upgrade_weapon():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please log in first.'})
    
    weapon_id = request.form.get('weapon_id')
    
    weapon = Weapon.query.get_or_404(weapon_id)
    ship = Ship.query.get(weapon.ship_id)
    
    # Make sure the ship belongs to the logged-in user
    if ship.user_id != session['user_id']:
        return jsonify({'success': False, 'message': 'Access denied.'})
    
    # Calculate upgrade cost
    upgrade_cost = weapon.level * 500
    
    if ship.credits < upgrade_cost:
        return jsonify({'success': False, 'message': 'Not enough credits for upgrade.'})
    
    # Perform upgrade
    ship.credits -= upgrade_cost
    weapon.level += 1
    weapon.damage += 5
    weapon.accuracy += 2
    
    db.session.commit()
    
    return jsonify({
        'success': True, 
        'message': f'{weapon.name} upgraded to level {weapon.level}',
        'new_level': weapon.level,
        'new_damage': weapon.damage,
        'new_accuracy': weapon.accuracy,
        'ship_credits': ship.credits
    })

@app.route('/attack/<int:ship_id>', methods=['GET', 'POST'])
def alien_attack(ship_id):
    if 'user_id' not in session:
        flash('Please log in first.')
        return redirect(url_for('login'))
    
    ship = Ship.query.get_or_404(ship_id)
    
    # Make sure the ship belongs to the logged-in user
    if ship.user_id != session['user_id']:
        flash('Access denied.')
        return redirect(url_for('dashboard'))
    
    # Generate a random alien for the attack
    alien_types = ["Klingon Warbird", "Romulan Scout", "Borg Cube", "Gorn Raider", "Tholian Weaver"]
    alien_name = random.choice(alien_types)
    
    # Scale alien difficulty based on ship's weapons
    avg_weapon_level = 1
    if ship.weapons:
        avg_weapon_level = sum(w.level for w in ship.weapons) / len(ship.weapons)
    
    # Adjusted alien stats to be more balanced for new players
    alien_health = random.randint(70, 120) + (avg_weapon_level - 1) * 20
    alien_damage = random.randint(4, 15) + (avg_weapon_level - 1) * 3
    alien_defense = random.randint(2, 8) + (avg_weapon_level - 1) * 1
    
    alien = Alien(name=alien_name, health=alien_health, damage=alien_damage, defense=alien_defense)
    db.session.add(alien)
    db.session.commit()
    
    if request.method == 'POST':
        weapon_id = request.form.get('weapon_id')
        weapon = Weapon.query.get_or_404(weapon_id)
        
        # Make sure the weapon belongs to the ship
        if weapon.ship_id != ship.id:
            flash('Invalid weapon selection.')
            return redirect(url_for('alien_attack', ship_id=ship.id))
        
        # Calculate hit chance
        hit_chance = weapon.accuracy
        
        # Apply crew bonus to accuracy (0.5 per crew member)
        crew_count = len(ship.crew)
        crew_bonus = crew_count * 0.5
        hit_chance += crew_bonus
        
        gunner = CrewMember.query.filter_by(ship_id=ship.id, role="Gunner").first()
        if gunner:
            hit_chance += gunner.skill_level * 2
        
        # Roll for hit
        roll = random.randint(1, 100)
        if roll <= hit_chance:
            # Calculate damage
            base_damage = weapon.damage
            
            # Apply crew bonus to damage (0.5 per crew member)
            base_damage += crew_bonus
            
            # Apply weapon level bonus
            base_damage += (weapon.level - 1) * 3
            
            damage = base_damage
            damage -= alien.defense
            damage = max(1, damage)  # Minimum 1 damage
            
            alien.health -= damage
            flash(f'Hit! {weapon.name} dealt {damage} damage to {alien.name}!')
        else:
            flash(f'Miss! {weapon.name} failed to hit {alien.name}!')
        
        # Alien attacks back if still alive
        if alien.health > 0:
            # Improved ship defense calculation
            ship_defense = 3  # Base defense value
            engineer = CrewMember.query.filter_by(ship_id=ship.id, role="Engineer").first()
            if engineer:
                ship_defense += engineer.skill_level
                
            ship_damage = max(1, alien.damage - ship_defense)  # Improved ship defense
            ship.health -= ship_damage
            flash(f'{alien.name} attacks and deals {ship_damage} damage to your ship!')
        else:
            # Alien defeated - increased rewards
            base_reward = random.randint(150, 600)
            reward = base_reward + (avg_weapon_level - 1) * 50
            ship.credits += reward
            flash(f'You defeated the {alien.name} and earned {reward} credits!')
            db.session.delete(alien)
        
        db.session.commit()
        
        if alien.health <= 0:
            return redirect(url_for('dashboard'))
        
        if ship.health <= 0:
            flash('Your ship has been destroyed!')
            return redirect(url_for('game_over'))
    
    return render_template('attack.html', ship=ship, alien=alien)

@app.route('/game_over')
def game_over():
    if 'user_id' not in session:
        flash('Please log in first.')
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    
    return render_template('game_over.html', user=user)

@app.route('/repair_ship', methods=['POST'])
def repair_ship():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please log in first.'})
    
    ship_id = request.form.get('ship_id')
    ship = Ship.query.get_or_404(ship_id)
    
    # Make sure the ship belongs to the logged-in user
    if ship.user_id != session['user_id']:
        return jsonify({'success': False, 'message': 'Access denied.'})
    
    # Reduced repair cost from 10 to 5 credits per health point
    repair_cost = (100 - ship.health) * 5
    
    if ship.credits < repair_cost:
        return jsonify({'success': False, 'message': 'Not enough credits for repair.'})
    
    ship.credits -= repair_cost
    ship.health = 100
    db.session.commit()
    
    return jsonify({
        'success': True, 
        'message': 'Ship repaired to full health!',
        'ship_health': ship.health,
        'ship_credits': ship.credits
    })

@app.route('/refill_resources', methods=['POST'])
def refill_resources():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please log in first.'})
    
    ship_id = request.form.get('ship_id')
    resource_type = request.form.get('resource')
    
    ship = Ship.query.get_or_404(ship_id)
    
    # Make sure the ship belongs to the logged-in user
    if ship.user_id != session['user_id']:
        return jsonify({'success': False, 'message': 'Access denied.'})
    
    if resource_type == 'fuel':
        # Reduced fuel cost from 5 to 2 credits per fuel point
        cost = (100 - ship.fuel) * 2
        if ship.credits >= cost:
            ship.credits -= cost
            ship.fuel = 100
        else:
            return jsonify({'success': False, 'message': 'Not enough credits.'})
    elif resource_type == 'oxygen':
        # Reduced oxygen cost from 3 to 1 credit per oxygen point
        cost = (100 - ship.oxygen) * 1
        if ship.credits >= cost:
            ship.credits -= cost
            ship.oxygen = 100
        else:
            return jsonify({'success': False, 'message': 'Not enough credits.'})
    elif resource_type == 'food':
        # Reduced food cost from 2 to 1 credit per food point
        cost = (100 - ship.food) * 1
        if ship.credits >= cost:
            ship.credits -= cost
            ship.food = 100
        else:
            return jsonify({'success': False, 'message': 'Not enough credits.'})
    else:
        return jsonify({'success': False, 'message': 'Invalid resource type.'})
    
    db.session.commit()
    
    return jsonify({
        'success': True, 
        'message': f'{resource_type.capitalize()} refilled to 100%!',
        'resource_level': 100,
        'ship_credits': ship.credits
    })

@app.route('/explore', methods=['GET', 'POST'])
def explore():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    ship = user.ships[0]  # For simplicity, we'll just use the first ship
    
    if request.method == 'POST':
        # Handle galaxy travel
        destination = request.form.get('galaxy')
        
        # Consume fuel for travel
        fuel_cost = random.randint(10, 30)
        if ship.fuel < fuel_cost:
            flash('Not enough fuel to travel!', 'danger')
            return redirect(url_for('explore'))
        
        ship.fuel -= fuel_cost
        
        # If traveling to unknown region, discover a new galaxy
        if destination == "Unknown Region":
            galaxy_names = ["Proxima Centauri", "Tau Ceti", "Epsilon Eridani", "Trappist System", "Kepler-186", 
                           "Wolf 359", "Gliese 581", "HD 40307", "Kapteyn's Star", "Ross 128"]
            available_names = [name for name in galaxy_names if not Galaxy.query.filter_by(name=name).first()]
            
            if available_names:
                new_galaxy_name = random.choice(available_names)
                new_galaxy = Galaxy(
                    name=new_galaxy_name,
                    danger_level=random.randint(1, 10),
                    resource_abundance=random.randint(1, 10),
                    description=f"A newly discovered galaxy with unknown wonders and dangers."
                )
                db.session.add(new_galaxy)
                db.session.commit()
                
                # Create resource points for the new galaxy
                create_resource_points_for_galaxy(new_galaxy)
                
                ship.current_galaxy = new_galaxy_name
            else:
                flash('No new galaxies to discover!', 'warning')
        else:
            ship.current_galaxy = destination
        
        db.session.commit()
        
        # Check for alien attack
        attack_chance = 30  # 30% chance of attack when traveling
        if random.random() * 100 < attack_chance:
            return redirect(url_for('alien_attack', ship_id=ship.id))
        
        return redirect(url_for('dashboard'))
    
    # Get list of known galaxies
    galaxies = Galaxy.query.all()
    
    # Generate some random galaxies if none exist
    if not galaxies:
        galaxy_names = ["Alpha Centauri", "Sirius System", "Betelgeuse Nebula", "Orion's Belt", "Andromeda Sector"]
        for name in galaxy_names:
            galaxy = Galaxy(
                name=name,
                danger_level=random.randint(1, 10),
                resource_abundance=random.randint(1, 10),
                description="A newly discovered galaxy."
            )
            db.session.add(galaxy)
        db.session.commit()
        galaxies = Galaxy.query.all()
    
    # Get current galaxy and its resource points
    current_galaxy = Galaxy.query.filter_by(name=ship.current_galaxy).first()
    resource_points = []
    
    if current_galaxy:
        # Check if the galaxy has resource points, if not create them
        if len(current_galaxy.resource_points) == 0:
            create_resource_points_for_galaxy(current_galaxy)
        
        # Regenerate resource points
        for point in current_galaxy.resource_points:
            point.regenerate()
        db.session.commit()
        
        resource_points = current_galaxy.resource_points
    
    return render_template('explore.html', ship=ship, galaxies=galaxies, resource_points=resource_points)

@app.route('/gather_credits', methods=['POST'])
def gather_credits():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please log in first.'})
    
    user = User.query.get(session['user_id'])
    ship = user.ships[0]  # For simplicity, we'll just use the first ship
    
    # Get resource point ID from request
    resource_point_id = request.json.get('resource_point_id')
    
    if not resource_point_id:
        return jsonify({'success': False, 'message': 'No resource point specified.'})
    
    # Check if the last harvest was less than 5 seconds ago
    last_harvest_time = session.get('last_harvest_time')
    if last_harvest_time:
        time_since_harvest = datetime.now() - datetime.fromisoformat(last_harvest_time)
        if time_since_harvest.total_seconds() < 5:
            seconds_remaining = int(5 - time_since_harvest.total_seconds())
            return jsonify({
                'success': False, 
                'message': f'Harvesting in progress. Please wait {seconds_remaining} seconds before gathering more resources.'
            })
    
    # Find the resource point
    resource_point = ResourcePoint.query.get(resource_point_id)
    
    if not resource_point:
        return jsonify({'success': False, 'message': 'Resource point not found.'})
    
    # Check if the resource point is in the current galaxy
    galaxy = Galaxy.query.filter_by(name=ship.current_galaxy).first()
    if resource_point.galaxy_id != galaxy.id:
        return jsonify({'success': False, 'message': 'This resource point is not in your current galaxy.'})
    
    # Check if there are credits available
    if resource_point.credits_available <= 0:
        return jsonify({'success': False, 'message': 'No resources available at this location. Try again later.'})
    
    # Check if ship has enough fuel
    fuel_cost = random.randint(1, 3)
    if ship.fuel < fuel_cost:
        return jsonify({'success': False, 'message': 'Not enough fuel to gather resources.'})
    
    # Harvest ALL credits from the resource point
    harvest_amount = resource_point.credits_available
    resource_point.credits_available = 0
    resource_point.last_harvested = datetime.now(timezone.utc)
    
    # Add credits to ship
    ship.credits += harvest_amount
    
    # Consume fuel
    ship.fuel -= fuel_cost
    
    # Update the last harvest time
    session['last_harvest_time'] = datetime.now().isoformat()
    
    db.session.commit()
    
    # Get updated resource points for the current galaxy
    resource_points = ResourcePoint.query.filter_by(galaxy_id=galaxy.id).all()
    resource_points_data = []
    
    for point in resource_points:
        resource_points_data.append({
            'id': point.id,
            'name': point.name,
            'credits_available': point.credits_available,
            'max_credits': point.max_credits
        })
    
    return jsonify({
        'success': True,
        'message': f'You harvested {harvest_amount} credits from {resource_point.name}!',
        'credits_earned': harvest_amount,
        'ship_credits': ship.credits,
        'ship_fuel': ship.fuel,
        'resource_point': {
            'id': resource_point.id,
            'name': resource_point.name,
            'credits_available': resource_point.credits_available,
            'max_credits': resource_point.max_credits
        },
        'resource_points': resource_points_data
    })

@app.route('/harvest_all_resources', methods=['POST'])
def harvest_all_resources():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please log in first.'})
    
    user = User.query.get(session['user_id'])
    ship = user.ships[0]  # For simplicity, we'll just use the first ship
    
    # Check if the last harvest was less than 5 seconds ago
    last_harvest_time = session.get('last_harvest_time')
    if last_harvest_time:
        time_since_harvest = datetime.now() - datetime.fromisoformat(last_harvest_time)
        if time_since_harvest.total_seconds() < 5:
            seconds_remaining = int(5 - time_since_harvest.total_seconds())
            return jsonify({
                'success': False, 
                'message': f'Harvesting mission in progress. Please wait {seconds_remaining} seconds before starting a new mission.'
            })
    
    # Get current galaxy and its resource points
    galaxy = Galaxy.query.filter_by(name=ship.current_galaxy).first()
    if not galaxy:
        return jsonify({'success': False, 'message': 'Current galaxy not found.'})
    
    resource_points = ResourcePoint.query.filter_by(galaxy_id=galaxy.id).all()
    if not resource_points:
        return jsonify({'success': False, 'message': 'No resource points found in this galaxy.'})
    
    # Check if ship has enough fuel for the mission
    fuel_cost = 5  # Fixed fuel cost for harvesting all resources
    if ship.fuel < fuel_cost:
        return jsonify({'success': False, 'message': 'Not enough fuel for a harvesting mission.'})
    
    # Harvest credits from all resource points
    total_harvest = 0
    harvested_points = []
    
    for point in resource_points:
        if point.credits_available > 0:
            harvest_amount = point.credits_available
            point.credits_available = 0
            point.last_harvested = datetime.now(timezone.utc)
            total_harvest += harvest_amount
            
            harvested_points.append({
                'id': point.id,
                'name': point.name,
                'credits_available': 0,
                'max_credits': point.max_credits,
                'amount_harvested': harvest_amount
            })
    
    # Add credits to ship and consume fuel
    ship.credits += total_harvest
    ship.fuel -= fuel_cost
    
    # Update the last harvest time
    session['last_harvest_time'] = datetime.now().isoformat()
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f'Harvesting mission complete! You collected {total_harvest} credits from all planets in the galaxy!',
        'total_credits_earned': total_harvest,
        'ship_credits': ship.credits,
        'ship_fuel': ship.fuel,
        'harvested_points': harvested_points
    })

if __name__ == '__main__':
    # Initialize the database before running the app
    initialize_db()
    app.run(debug=True) 