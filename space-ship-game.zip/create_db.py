from app import initialize_db

# Initialize the database
initialize_db()

print("Database initialized successfully!") 